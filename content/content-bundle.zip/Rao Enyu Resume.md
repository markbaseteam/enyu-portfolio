## Rao Enyu Resume 
`A Knack for Creative, Out-Of-Box Ideas`
`Get In Touch`
> 	[💡 LinkedIn](https://www.linkedin.com/in/enyu-rao/)      📬 [Gmail](mailto:rao.enyu1@gmail.com)      [☎️ Phone #](tel:(781)308-9696)     
> 	 [📥 Telegram](https://t.me/z0ne_30)     [🐦 Twitter](https://twitter.com/0xhappier)       [📡 Warpcast](https://warpcast.com/z0ne-30)

### Education 
> 	🦫 **Babson College, Wellesley, MA** 
> 		*• First Gen. B.S. Business Administration, Cum laude, Concentration in Strategic Management & Economics  
> 		• Coursework: Quantitative Business Analytics I-IV, Global Strategic Management, Alternative Investments, Principals of Macro & Microeconomics, Strategic Decision Making, Operational Management, Business Law*

> 	🇨🇭 **Universität St. Gallen, St. Gallen, Switzerland**
> 		*• Exchange Semester B.S. in Business Administration  
> 		• Coursework: Experimental & Behavioral Econ, Game Theory & Applications, Interational Trade Theory & Policy*

---
### Experience
> 	⛓️ Co-Founder, Product & Business Development
> 	PlayIn Technologies      (10/2021 - 01/2023)
> 		• *Orchestrated blockchain architecture and mechanism design to facilitate peer-to-peer skill-based gaming upon the Polygon Blockchain Coordinated UI/UX design to align with company product vision, led user research/beta testing efforts  
> 		• Organized strategic partnerships to boost GTM by outreaching to industry dial-movers and pitching to potential stakeholders for funding/ growth of PlayIn Technologies*

> 	♟️ **Strategy Consultant**
> 	Clarkston Consulting      (09/2021 - 12/2021)
> 		• *Collaborated with a team of 6 to model and map out a five-year industry outlook on the adaptation of crypto & blockchain technologies in the retail market    
> 		• Recommended various strategies for clients by performing risks and opportunities analysis on the adaptation of crypto payment methods and blockchain technologies*

> 	📈 **Director of Strategic Partnerships**
> 	Kuvio Creative      (06/2020 - 08/2021)     
> 		• *Led the Sales Strategy development by systematizing retainer partnerships with clients to sustain long-term affiliation, with 15% client conversion, and 80% client retention  
> 		• Building the bridge to give small businesses affordable access to design expertise agencies, debunking the status quo of over-inflated paid agency work*

> 	🌳 **Founding Team, Project Manager**
> 	Fishbowl Challenge     (09/2019 - 09/2022)     
> 		• *Led the structured 6-month entrepreneurial program design for Fishbowl Challenge V1-V3, and fundraising efforts of raising $100,000, while creating an adjacent high school program as a funding tunnel to the nonprofit operations   
> 		• Accepted 100 Challengers from elite universities across the globe to solve the world’s biggest social issues with $50,000 awarded to the top 5 teams
> 		• Recruited 1400+ applicants and achieved organic growth of 1000+ followers across 4 social media channels through engaging collateral & campaigns*

> 	 🪙 **Global Treasuries Intern**
> 	State Street Bank     (05/2018 - 09/2018)     
> 		• *Worked with State Street's Global Treasury team, managing the company balance sheet and optimizing net interest income (NII), monitoring asset-liability risk, liquidity risk, funding, liability pricing, capital structure, and rating agency relationships  
> 		• Assisted in the closing of 2500 State Street client’s Cayman Branch accounts, by prepping over 6000 tax documents for filing  
> 		• Gained a deep understanding of financial and operational aspects of Treasury activities, including derivatives and hedging*

---
### Relevant Portfolio
> 	🚗 **M&A Strategy Analyst** 
> 	Strategic Decision-Making [Paper](https://enyu-portfolio.markbase.xyz/Acquisition%20recommendation%20to%20%20Tesla%20Inc.)
> 		• *Conducted in-depth analysis of the EV Industry, recommended an international high-growth opportunity for Tesla Inc through acquisition 
> 		• Applied target analysis frameworks of Industry Attractiveness (Porter’s Five Forces), Competitive Advantage, and Net-Present Value tests to evaluate Contemporary Amperex Technology Co. Limited, Nikola Corporation, and Lucid Motors Inc. as potential acquisition targets*

> 	💰 **Fintech Strategy Analyst**
> 	Strategic Problem-Solving [Paper](https://enyu-portfolio.markbase.xyz/Revenue%20Growth%20Recommendation%20to%20Apple%20Inc.)
> 		• *Developed a two-pronged strategy for Apple Inc. to boost revenues by 20% and achieve a minimum NPV of $52B within 3-5 years by examining the Five Elements of Strategy and Porter’s Five Forces frameworks  
> 		• Recommended Apple’s growth in the Gaming industry by developing a console ecosystem with a competitive selection of cross-platform games, as well as expansion of Apple’s financial service offerings through the proliferation of Fintech APIs and introduction of AppleCoin*

---
### Skills & Interests
> 	• Skills: *R Studio, Tableau, C, Python, Mechanism Design, Project Management, M&A Strategy Assessment, Optimization Market Research, Figma, Adobe InDesign, Native Chinese Speaker, German A1, Strong Interpersonal Skills, Knack For Out-Of-The-Box Ideas*
> 	• Interests: *Hiking & Backpacking, Snowboarding, Inter-railing, AI, Philosophy, Behavioral Economics*

